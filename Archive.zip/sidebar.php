
   <div class="panel">
               <ul class="nav nav-pills nav-stacked">
                  <li><a href="my_account.php"><div class="icon-preview"><i class="mdi-action-dashboard"></i></div>Dashboard</a></li>
                  <li><a href="buy.php"><div class="icon-preview"><i class="mdi-action-add-shopping-cart"></i></div>Buy</a></li>
                  <li><a href="sell.php"><div class="icon-preview"><i class="mdi-action-store"></i></div>Sell</a></li>

               </ul>
                </div>
    

