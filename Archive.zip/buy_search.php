<?php
 echo $_POST["sub_category"];

echo $_POST["latitude"];
echo $_POST["longitude"];
?>

