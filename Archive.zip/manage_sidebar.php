
   <div class="panel">
               <ul class="nav nav-pills nav-stacked">
                   <li><a href="manage.php"><div class="icon-preview"><i class="mdi-action-view-module"></i></div>Dashboard</a></li>
                  <li><a href="employee.php"><div class="icon-preview"><i class="mdi-action-account-child"></i></div>Employee</a></li>
                  <li><a href="#"><div class="icon-preview"><i class="mdi-action-note-add"></i></div>Item</a></li>
                  <li><a href="#"><div class="icon-preview"><i class="mdi-action-shopping-cart"></i></div>Order</a></li>
				  <li><a href="#"><div class="icon-preview"><i class="mdi-action-shopping-basket"></i></div>Stock</a></li>
				  <li><a href="#"><div class="icon-preview"><i class="mdi-action-wallet-giftcard"></i></div>Promo Code</a></li>
				  <li><a href="#"><div class="icon-preview"><i class="mdi-action-settings"></i></div>Store Config</a></li>



               </ul>
                </div>
    
