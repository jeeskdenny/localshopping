<div class="panel panel-body panel-primary">
							<a href="ad_single_item.php" class="btn btn-success btn-fab btn-fab-mini"  class="icon-preview" ><i class="mdi-action-note-add"></i> </a>
							<a href="update_sell.php" class="btn btn-warning btn-fab btn-fab-mini"  class="icon-preview" ><i class="mdi-action-cached"></i> </a>		
							<a href="delete_sell.php" class="btn btn-danger btn-fab btn-fab-mini"  class="icon-preview" ><i class="mdi-action-delete"></i> </a>	

							</br>

							
						</div>